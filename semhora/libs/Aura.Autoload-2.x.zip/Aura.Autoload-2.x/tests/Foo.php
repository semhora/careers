<?php
namespace Aura\Autoload;
class Foo
{
}
