<?php
namespace Baz\Qux;

class Quux
{
    public function exec()
    {
        return 'Quux';
    }
}
