<?php
namespace Aura\Autoload;
class Bar
{
}
