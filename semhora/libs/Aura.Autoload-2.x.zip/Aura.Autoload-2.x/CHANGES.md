Hygiene release: update the license year, and remove a branch alias.
